# Study Guide — *From Behaviorism to Language Models: A Formal Correspondence Between the Matching Law and Token Prediction*

> **Audience:** graduate students and advanced undergraduates in psychology, cognitive science, machine learning, and related fields.  
> **Goal:** make the preprint maximally accessible by explaining background, acronyms, key equations, theorem derivations, and the broader research agenda.

---

## How to Use This Guide
1. **Read the Background Primer** to level‑set on behaviorism, LLM training, and the math objects we use (cross‑entropy, KL, logits).
2. **Walk through the Theorem Roadmap** step‑by‑step; each theorem includes assumptions, derivation sketch, intuition, and pitfalls.
3. **Consult the Glossary** whenever acronyms or terms appear.
4. **Use the Exercises** to build intuition with simple numbers.
5. **Browse the Research Program** (Table 1 expansion) for project ideas and empirical tests.

---

## Background Primer

### Behaviorism & the Matching Law (Operant Conditioning)
- **Operant conditioning:** behavior is shaped by its consequences (reinforcement schedules).  
- **Matching law (Herrnstein):** an organism’s **allocation of responses** across options matches the **allocation of reinforcement** across those options.  
  - If option A delivers 70% of rewards and option B 30%, responses tend toward a 70:30 ratio (**strict matching**).
- **Generalized matching (Baum):** real agents depart from perfect matching. Two parameters summarize this:
  - **Sensitivity** (*slope*): how strongly responses track reinforcement differences.
  - **Bias** (*intercept*): systematic preference for one option independent of reinforcement.

### LLMs: Training, Alignment, Inference
- **Pretraining (Maximum Likelihood / Cross‑Entropy):** learn to assign high probability to observed next tokens. Equivalent to minimizing the divergence between model distribution \(\pi_\theta(\cdot\mid c)\) and corpus distribution \(q(\cdot\mid c)\).
- **Alignment (RLHF / DPO):** introduce **preferences/rewards** and a **KL penalty** that keeps the new policy near a reference policy.
- **Inference (Decoding):** use **temperature** and related controls to modulate variability in samples.

---

## Theorem Roadmap — Derivations, Intuition, Pitfalls

### Theorem 1 — **Strict Matching under MLE**
**Claim.** If the corpus conditional \(q(\cdot\mid c)\) is representable by the model class, minimizing cross‑entropy yields a model \(\pi^*\) with \(\pi^*(\cdot\mid c)=q(\cdot\mid c)\). Therefore, for any two continuations \(a,b\):
\[\frac{\pi^*(a\mid c)}{\pi^*(b\mid c)}=\frac{q(a\mid c)}{q(b\mid c)}\quad\text{(strict matching)}.\]

**Assumptions.**
1. The model has capacity to represent \(q(\cdot\mid c)\) (the “realizable” case).
2. Optimization finds a global minimum (idealized limit).

**Derivation (3 steps).**
1. Write the MLE objective as cross‑entropy: \(\mathcal{L}_{\text{MLE}}=\mathbb{E}_{(c,y)\sim q}[-\log \pi_\theta(y\mid c)] = \mathbb{E}_{c\sim q}[H(q(\cdot\mid c),\pi_\theta(\cdot\mid c))]\).
2. Use the identity \(H(q,\pi)=H(q)+\mathrm{KL}(q\Vert \pi)\).
3. Since \(H(q)\) is constant in \(\theta\), minimization reduces to minimizing \(\mathrm{KL}(q\Vert \pi)\), which is \(0\) iff \(\pi=q\).

**Intuition.** MLE is “copy the data distribution.” Matching law says “allocate responses in proportion to reinforcement.” Both describe **allocation matching contingencies**.

**Pitfalls / Finite Effects.** Limited capacity, limited data, label smoothing, and regularization introduce **undermatching** (sensitivity < 1) and **bias** (intercepts ≠ 0).

---

### Theorem 2 — **Generalized Matching via KL‑Regularized Preference Optimization**
**Claim.** Maximizing expected reward with a KL penalty to a reference policy yields:
\[\pi^*(y\mid x)\propto \pi_{\text{ref}}(y\mid x)\,\exp\{\beta\, r(x,y)\}.\]
Therefore, for any two responses \(y_1,y_2\):
\[\log\frac{\pi^*(y_1\mid x)}{\pi^*(y_2\mid x)}
=\log\frac{\pi_{\text{ref}}(y_1\mid x)}{\pi_{\text{ref}}(y_2\mid x)}+\beta\,[r(x,y_1)-r(x,y_2)],\]
i.e., **generalized matching** with **bias** from \(\pi_{\text{ref}}\) and **sensitivity** \(s=\beta\).

**Assumptions.**
1. We optimize \(\mathcal{J}(\pi)=\mathbb{E}_{y\sim\pi}[r(x,y)]-\beta\,\mathrm{KL}(\pi\Vert \pi_{\text{ref}})\) for fixed \(x\).
2. Regular conditions ensuring a unique interior maximizer (finite support or appropriate smoothness).

**Derivation (4 steps).**
1. Set up Lagrangian with normalization constraint.  
2. Take derivative w.r.t. \(\pi(y)\) and set to zero.  
3. Rearrange: \(\pi(y)\propto \pi_{\text{ref}}(y)\exp\{\beta r(x,y)\}\).  
4. Normalize to obtain the stated form; subtract log‑odds to get the generalized matching equation.

**Intuition.** The KL penalty keeps you near the **reference** (bias term), while the reward scales your move by **\(\beta\)** (sensitivity).

**Pitfalls.** Reward misspecification; mode collapse if \(\beta\) too large; if \(\pi_{\text{ref}}\) is very peaked, apparent bias can dominate.

---

### Theorem 3 — **Temperature Scaling as Sensitivity Rescaling**
**Claim.** Sampling from \(\pi_T(y\mid x)\propto \pi(y\mid x)^{1/T}\) yields:
\[\log\frac{\pi_T(y_1\mid x)}{\pi_T(y_2\mid x)}=\frac{1}{T}\log\frac{\pi(y_1\mid x)}{\pi(y_2\mid x)}.\]
Thus, **temperature \(T\)** rescales **sensitivity**.

**Derivation.** Apply the definition of temperature scaling to logits \(z(y)\): \(\pi_T\propto \exp\{z(y)/T\}\). Taking log‑odds gives the factor \(1/T\).

**Intuition.** Temperature is a **dial** on variability.

**Pitfalls.** Very low \(T\) may cause deterministic repetition; very high \(T\) degrades coherence.

---

### Theorem 4 — **Mixtures and Regularization**
**Claim.** If the corpus is a mixture \(q=\sum_k \alpha_k q^{(k)}\), MLE yields \(\pi^*=q\). Regularizers that shrink logits produce **undermatching** (slopes < 1).

**Intuition.** Mixtures shift base‑rates; regularization “pulls toward uniform” or toward a reference, both of which show up as undermatching.

---

## Expanded Glossary with Context and Mathematics

### KL — Kullback–Leibler Divergence
- Definition: \(\mathrm{KL}(p\Vert q)=\sum_x p(x)\log\frac{p(x)}{q(x)}\).  
- Context: links MLE (copy data) and alignment (bias toward reference).  

### MLE — Maximum Likelihood Estimation
- Definition: maximize likelihood of data.  
- Context: strict matching analogue.

### RLHF — Reinforcement Learning from Human Feedback
- Definition: align with human preferences using reward + KL penalty.  
- Context: generalized matching law.

### DPO — Direct Preference Optimization
- Definition: align directly from preference pairs.  
- Context: still fits generalized matching.

### Cross‑Entropy
- Definition: \(H(q,\pi)=-\sum_x q(x)\log \pi(x)=H(q)+\mathrm{KL}(q\Vert \pi)\).  
- Context: core pretraining loss.

### Policy
- Definition: conditional distribution \(\pi(y\mid x)\).  
- Context: maps tokens to actions.

### Logits
- Definition: unnormalized scores \(z_i\); softmax: \(\pi(y=i)=\frac{\exp(z_i)}{\sum_j \exp(z_j)}\).  
- Derivative: \(\frac{\partial \pi(y=i)}{\partial z_k} = \pi(y=i)(\delta_{ik}-\pi(y=k))\).  
- CDF: \(F(k)=\sum_{i \le k} \pi(y=i)\).  
- Inverse CDF: choose smallest \(k\) with \(F(k)\geq u, u\sim U[0,1]\).  
- Context: logits ↔ odds ratios.

### Temperature
- Definition: \(\pi_T(i)=\frac{\exp(z_i/T)}{\sum_j \exp(z_j/T)}\).  
- Context: sensitivity rescaling.

### Sensitivity and Bias
- Definition: slope and intercept in generalized matching law.  
- Context: sensitivity ↔ KL weight or \(1/T\); bias ↔ reference model.

---